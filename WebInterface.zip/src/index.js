import React from 'react';
import ReactDOM from 'react-dom';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.js';
import 'bootstrap/dist/js/bootstrap.bundle';
import './index.css';

import SocketIO from 'socket.io-client';
import { Serial } from './serial.js';
import $ from 'jquery';
require('bootstrap');

const HOSTSTATIC = "127.0.0.1"; 

class OnlineGBGame extends React.Component {
  constructor(props)
  {
   super(props);
   console.log("Component init...");
   this.state = {
      currentState : 0,
      master : 1,
      gbdatain : 0,
      gbdataout : 0,
      connectedStatus : 0,
      roomJoinedName : "Default_Room",
      lastmsg : "No message",
   };
  
   console.log("Creating GBWebsocket ...");
   this.ws = new SocketIO.connect("http://127.0.0.1:8080"); // "http://"+HOSTSTATIC+":8080"
   console.log("OK.");
   console.log("Creating Serial ...");
   this.serial = new Serial();
   console.log("OK.");
   $("#room_name").prop('readonly', false);
  }

  handleC() { // Handle create (master mode)
    console.log('Click create');
      console.log("Creating serial ...");
      this.setState({ master : 1});
      console.log("Initializing websocket gymnastic ! (onmessage function)");
      console.log("Getting device ...");
      this.serial.getDevice().then(() => {
        console.log("Usb connected, updating status.");
        console.log("Room name in input : "+this.state.roomJoinedName);
        this.ws.emit('join', {room: this.state.roomJoinedName});
        this.setState({ currentState: 1, connectedStatus : 1 });
        this.connectionMaster();
      }).catch(c => {
        console.log("CATTTCH "+c);
      });
  }
  
  handleJ() { // Handle Join (master mode off)
    console.log('Click create');
      console.log("Creating serial ...");
      this.setState({ master : 0});
      console.log("Initializing websocket gymnastic ! (onmessage function)");
      console.log("Getting device ...");
      this.serial.getDevice().then(() => {
        console.log("Usb connected, updating status.");
        console.log("Room name in input : "+this.state.roomJoinedName);
        this.ws.emit('join', {room: this.state.roomJoinedName});
        this.setState({ currentState: 1, connectedStatus : 1 });
        this.connectionNotMaster();
      }).catch(c => {
        console.log("CATTTCH "+c);
      });
  }

  connectionNotMaster()
  {
    var me = this;

    this.ws.on('connect', function() {
      me.ws.emit('my_event', {data: 'I\'m connected!'});
      me.setState({ lastmsg : "Connected", connectedStatus: 1 });
    });
    this.ws.on('disconnect', function() {
        me.connectedStatus = 0;
        me.setState({ lastmsg : "Disconnected" });
    });

    this.ws.on("my_response", function(msg){
      console.log("Message received !!! (my_response) : "+ msg["data"]);
      me.setState({ lastmsg : msg["data"] });
      console.log("Waiting for external GB Communication");
    });

    this.ws.on("gb_com", function(msg){
      // Send msg["data"] to my GB serial
      console.log("Serial communication received : " + msg["data"]);
      me.setState({ gbdatain : msg["data"] });
      me.serial.sendHex(msg["data"]);

      me.serial.readHex(64).then(result => {
        console.log("Reading 64 bits SUCCESS! value : "+result+" \n");
        //me.setState({gbdataout:result});
        console.log("Sending Hex code to WSocket");
        me.ws.emit('gb_com', {data: result, room: me.state.roomJoinedName});
      },
      error => {
        console.log("ERROR");
        console.log(error);
      });
    });
  }

  connectionMaster() {
    var me = this;

    this.ws.on('connect', function() {
      me.ws.emit('my_event', {data: 'I\'m connected!'});
      me.setState({ lastmsg : "Connected", connectedStatus: 1 });
    });
    this.ws.on('disconnect', function() {
        me.connectedStatus = 0;
        me.setState({ lastmsg : "Disconnected" });
    });

    this.ws.on("my_response", function(msg){
      console.log("Message received !!! (my_response) : "+ msg["data"]);
      me.setState({ lastmsg : msg["data"] });

      console.log("Reading 64 bit of GB ...");
      // Read serial then send it to websocket (100 miliseconds)
      me.serial.sendHex("00");
      me.serial.readHex(64).then(result => {
          console.log("Reading 64 bits SUCCESS! value : "+result+" \n");
          //me.setState({gbdataout:result});
          console.log("Sending Hex code to WSocket");
          me.ws.emit('gb_com', {data: result, room: me.state.roomJoinedName});
      },
      error => {
        console.log("ERROR");
        console.log(error);
      });
      console.log("Promise done.");
    });

    this.ws.on("gb_com", function(msg){
      // Send msg["data"] to my GB serial
      console.log("Serial communication received : " + msg["data"]);
      me.setState({ gbdatain : msg["data"] });
      me.serial.sendHex(msg["data"]);
    });
  }

  handleChange(value) {
    this.setState({roomJoinedName : value});
  }

  render() {
    if(this.state.currentState === 0){
                return (
                <div className="connect">
                    <h4>Gameboy relay (choose wether to by master or client)</h4>
                    <button onClick={(e) => this.handleC()} className="btn btn-lg btn-secondary">Host (Master)</button><span>    </span>
                    <button onClick={(e) => this.handleJ()} className="btn btn-lg btn-secondary">Connect (Client)</button><br />
                    <br/><br/>
                    <form>
                      <h4>Room name : {this.state.roomJoinedName} </h4>
                      <input className="form-control" id="room_name" name="room_name" type="text" onChange={(e) => {this.handleChange(e.target.value) }}/>
                    </form>
                </div>
                )
    }
    else {
      return (
                  <div className="connect">
                    <div> <b>Connected :</b>{ this.state.connectedStatus } <br/> <b>Room joined :</b> {  this.state.roomJoinedName } <br/> <b>Last message :</b> {  this.state.lastmsg }  </div>
                    <br/><b>(Master : {  this.state.master }) <br/> Connected : <br/>IN <u>{  this.state.gbdatain }</u> <br/>OUT <u>{  this.state.gbdataout }</u></b>
                  </div>
                )
   }
  }
}

// ========================================

ReactDOM.render(
  <OnlineGBGame />,
  document.getElementById('root')
);
